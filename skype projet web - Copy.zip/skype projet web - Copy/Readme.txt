Nom      : saintilien
Prenom   : yolaine saintilus
Code     : 33706
Section  : Sces informatiques
Vacation : median A
Niveau   : 2e annee